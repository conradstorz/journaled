from datetime import date
from decimal import Decimal
from sqlalchemy import select
from ledger_app.models import Account, Statement, StatementLine, Transaction, Split
from ledger_app.seeds import seed_chart_of_accounts
from ledger_app.services.reconcile import ReconcileParams, propose_matches, apply_match, status

def setup_accounts(db):
    seed_chart_of_accounts(db)
    cash = db.execute(select(Account).where(Account.name == "Checking Account")).scalar_one()
    expense = db.execute(select(Account).where(Account.name == "Expenses")).scalar_one()
    return cash.id, expense.id

def test_reconciliation_flow(session_from_url):
    db = session_from_url
    cash_id, expense_id = setup_accounts(db)

    tx = Transaction(date=date(2025,1,5), description="Office supplies")
    db.add(tx); db.flush()
    s1 = Split(transaction_id=tx.id, account_id=cash_id, amount=Decimal("-50.00"), memo="OFFICE")
    s2 = Split(transaction_id=tx.id, account_id=expense_id, amount=Decimal("50.00"), memo="OFFICE")
    db.add_all([s1,s2]); db.commit()

    stmt = Statement(account_id=cash_id, period_start=date(2025,1,1), period_end=date(2025,1,31),
                     opening_bal=Decimal("1000.00"), closing_bal=Decimal("950.00"))
    db.add(stmt); db.flush()

    line = StatementLine(statement_id=stmt.id, posted_date=date(2025,1,6),
                         amount=Decimal("-50.00"), description="OFFICE SUPPLIES")
    db.add(line); db.commit()

    params = ReconcileParams(account_id=cash_id, period_start=date(2025,1,1), period_end=date(2025,1,31))
    props = propose_matches(db, params)
    assert any(p.line_id == line.id for p in props)

    best = sorted(props, key=lambda p: p.score)[0]
    apply_match(db, best.line_id, best.split_id)

    st = status(db, params)
    assert st.matched_lines == 1
    assert st.difference == Decimal("0.00")
