from __future__ import annotations
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable, List, Optional, Tuple

from sqlalchemy import select, func
from sqlalchemy.orm import Session

from ..models import Statement, StatementLine, Split, Transaction

@dataclass
class ReconcileParams:
    account_id: int
    period_start: date
    period_end: date
    amount_tolerance: Decimal = Decimal("0.01")
    date_window_days: int = 3

@dataclass
class ProposedMatch:
    line_id: int
    split_id: int
    score: int  # lower is better (0 best)
    reason: str

@dataclass
class ReconcileStatus:
    opening_bal: Decimal
    closing_bal: Decimal
    sum_lines: Decimal
    book_delta: Decimal
    stmt_delta: Decimal
    difference: Decimal  # stmt_delta - book_delta
    matched_lines: int
    unmatched_lines: int
    matched_amount: Decimal

def _sum_decimal(values: Iterable[Decimal]) -> Decimal:
    total = Decimal("0.00")
    for v in values:
        total += Decimal(v)
    return total

def get_statement(session: Session, account_id: int, period_start: date, period_end: date) -> Statement:
    stmt = session.execute(
        select(Statement).where(
            Statement.account_id == account_id,
            Statement.period_start == period_start,
            Statement.period_end == period_end,
        )
    ).scalar_one_or_none()
    if not stmt:
        raise ValueError("Statement not found for given account and period")
    return stmt

def list_unmatched_lines(session: Session, statement_id: int) -> list[StatementLine]:
    rows = session.execute(
        select(StatementLine).where(
            StatementLine.statement_id == statement_id,
            StatementLine.matched_split_id.is_(None),
        ).order_by(StatementLine.posted_date, StatementLine.amount, StatementLine.id)
    ).scalars().all()
    return rows

def list_candidate_splits(
    session: Session,
    account_id: int,
    period_start: date,
    period_end: date,
    amount: Decimal,
    posted_date: date,
    params: ReconcileParams,
) -> list[Split]:
    # Candidate splits on this account in a date window (to allow bank vs books timing)
    start_w = posted_date - timedelta(days=params.date_window_days)
    end_w = posted_date + timedelta(days=params.date_window_days)
    rows = session.execute(
        select(Split)
        .join(Transaction, Transaction.id == Split.transaction_id)
        .where(
            Split.account_id == account_id,
            Transaction.date >= start_w,
            Transaction.date <= end_w,
            func.abs(Split.amount - amount) <= params.amount_tolerance,
        )
        .order_by(Transaction.date, Split.amount, Split.id)
    ).scalars().all()
    return rows

def score_match(line: StatementLine, split: Split) -> Tuple[int, str]:
    score = 100
    reasons = []
    # Amount exact within cent tolerance
    if abs(Decimal(split.amount) - Decimal(line.amount)) <= Decimal("0.01"):
        score -= 50
        reasons.append("amount")
    # Date proximity
    d = abs((line.posted_date - split.transaction.date).days)
    if d == 0:
        score -= 30
        reasons.append("date=0")
    elif d <= 3:
        score -= 20
        reasons.append("date<=3")
    elif d <= 7:
        score -= 10
        reasons.append("date<=7")
    # Memo/description heuristic
    if line.description and split.memo and line.description.lower()[:8] == split.memo.lower()[:8]:
        score -= 5
        reasons.append("memo-prefix")
    return max(0, 100 - score), ",".join(reasons) if reasons else "heuristic"

def propose_matches(session: Session, params: ReconcileParams) -> list[ProposedMatch]:
    stmt = get_statement(session, params.account_id, params.period_start, params.period_end)
    lines = list_unmatched_lines(session, stmt.id)
    proposals: list[ProposedMatch] = []
    for line in lines:
        candidates = list_candidate_splits(
            session,
            params.account_id,
            params.period_start,
            params.period_end,
            Decimal(line.amount),
            line.posted_date,
            params,
        )
        best: Optional[Tuple[Split, int, str]] = None
        for split in candidates:
            if session.get(StatementLine, line.id).matched_split_id is not None:
                break
            already = session.execute(
                select(StatementLine).where(StatementLine.matched_split_id == split.id)
            ).first()
            if already:
                continue
            s, reason = score_match(line, split)
            if not best or s < best[1]:
                best = (split, s, reason)
        if best:
            proposals.append(ProposedMatch(line_id=line.id, split_id=best[0].id, score=best[1], reason=best[2]))
    proposals.sort(key=lambda p: p.score)
    return proposals

def apply_match(session: Session, line_id: int, split_id: int) -> None:
    line = session.get(StatementLine, line_id)
    if not line:
        raise ValueError("StatementLine not found")
    if line.matched_split_id:
        if line.matched_split_id == split_id:
            return
        raise ValueError("StatementLine already matched to a different split")
    split = session.get(Split, split_id)
    if not split:
        raise ValueError("Split not found")
    existing = session.execute(select(StatementLine).where(StatementLine.matched_split_id == split_id)).scalar_one_or_none()
    if existing:
        raise ValueError("Split already matched by another statement line")
    line.matched_split_id = split_id
    session.add(line)
    session.commit()

def unmatch(session: Session, line_id: int) -> None:
    line = session.get(StatementLine, line_id)
    if not line:
        raise ValueError("StatementLine not found")
    line.matched_split_id = None
    session.add(line)
    session.commit()

def status(session: Session, params: ReconcileParams) -> ReconcileStatus:
    stmt = get_statement(session, params.account_id, params.period_start, params.period_end)
    lines = session.execute(select(StatementLine).where(StatementLine.statement_id == stmt.id)).scalars().all()
    sum_lines = _sum_decimal(l.amount for l in lines)
    matched_split_ids = [l.matched_split_id for l in lines if l.matched_split_id is not None]
    matched_amount = Decimal("0.00")
    if matched_split_ids:
        splits = session.execute(select(Split).where(Split.id.in_(matched_split_ids))).scalars().all()
        matched_amount = _sum_decimal(s.amount for s in splits)
    stmt_delta = Decimal(stmt.closing_bal) - Decimal(stmt.opening_bal)
    book_delta = matched_amount
    difference = stmt_delta - book_delta
    matched_lines = sum(1 for l in lines if l.matched_split_id is not None)
    return ReconcileStatus(
        opening_bal=Decimal(stmt.opening_bal),
        closing_bal=Decimal(stmt.closing_bal),
        sum_lines=sum_lines,
        book_delta=book_delta,
        stmt_delta=stmt_delta,
        difference=difference,
        matched_lines=matched_lines,
        unmatched_lines=len(lines) - matched_lines,
        matched_amount=matched_amount,
    )
